var searchData=
[
  ['net_5fbuf_5fsize',['NET_BUF_SIZE',['../q2-client_8c.html#a30ba2113ad1b0f91029d017fc988d9af',1,'NET_BUF_SIZE():&#160;q2-client.c'],['../q2-server_8c.html#a30ba2113ad1b0f91029d017fc988d9af',1,'NET_BUF_SIZE():&#160;q2-server.c']]],
  ['nofile',['nofile',['../q2-server_8c.html#a49e1fa6b4860231cbcb87bd74f65569f',1,'q2-server.c']]]
];
