var searchData=
[
  ['sendfile',['sendFile',['../q2-server_8c.html#a19fc2d7afbfbca5d5b78534e8eeb6b29',1,'q2-server.c']]],
  ['sendrecvflag',['sendrecvflag',['../q2-client_8c.html#a6e618c0ec6ffc8ac4489d11c65a5a67c',1,'sendrecvflag():&#160;q2-client.c'],['../q2-server_8c.html#a6e618c0ec6ffc8ac4489d11c65a5a67c',1,'sendrecvflag():&#160;q2-server.c']]],
  ['separate',['separate',['../q1_8c.html#a5f90e3b26836b8a0ff338c925198593d',1,'q1.c']]]
];
