var searchData=
[
  ['cipher',['Cipher',['../q2-server_8c.html#a4fc6ad5854f646cf1e284f66e104219f',1,'q2-server.c']]],
  ['cipherkey',['cipherKey',['../q2-client_8c.html#abace6f1e028b11cc237bd95c5dbe451a',1,'cipherKey():&#160;q2-client.c'],['../q2-server_8c.html#abace6f1e028b11cc237bd95c5dbe451a',1,'cipherKey():&#160;q2-server.c']]],
  ['clearbuf',['clearBuf',['../q2-client_8c.html#a37e9b2e0b0fcbe7d2d5bd9c9467c1fb8',1,'clearBuf(char *b):&#160;q2-client.c'],['../q2-server_8c.html#a37e9b2e0b0fcbe7d2d5bd9c9467c1fb8',1,'clearBuf(char *b):&#160;q2-server.c']]]
];
