var searchData=
[
  ['main',['main',['../q1_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;q1.c'],['../q2-server_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;q2-server.c'],['../q2__dummy_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;q2_dummy.c']]]
];
