var searchData=
[
  ['sendrecvflag',['sendrecvflag',['../q2-client_8c.html#a6e618c0ec6ffc8ac4489d11c65a5a67c',1,'sendrecvflag():&#160;q2-client.c'],['../q2-server_8c.html#a6e618c0ec6ffc8ac4489d11c65a5a67c',1,'sendrecvflag():&#160;q2-server.c']]]
];
