var searchData=
[
  ['port_5fno',['PORT_NO',['../q2-client_8c.html#a47a4d3bbd05894abbce0ffd1d266aa88',1,'PORT_NO():&#160;q2-client.c'],['../q2-server_8c.html#a47a4d3bbd05894abbce0ffd1d266aa88',1,'PORT_NO():&#160;q2-server.c']]]
];
