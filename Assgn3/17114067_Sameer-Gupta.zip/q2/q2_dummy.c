#include<stdio.h>

int main()
{
	printf("Hay this is a Dummy file, ");
	printf("it means Data is received");
return 0;
}
